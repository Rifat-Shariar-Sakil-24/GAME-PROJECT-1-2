package com.mygdx.game.extra.setAllVariables;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.mygdx.game.TheLastLife;
import com.mygdx.game.coins.pointsOnMazeForCoins.FrightenedModeCoinPoints;
import com.mygdx.game.coins.pointsOnMazeForCoins.LegalButNoCoinPoints;
import com.mygdx.game.coins.pointsOnMazeForCoins.LegalPoints;

public class SetAllVariablesForNewRound extends TheLastLife {
    public SetAllVariablesForNewRound()
    {

        timeState=0f;
        timeElapsedForPauseToMovementRedMonster = 0;
        timeElapsedForModeChangeRedMonster= 0;



        //Pacman all variables
        arcRight = false;arcLeft=false;arcUp=false;arcDown=false;
        arcMovementOn = false;
        arcX = (14*cellWidth)+ (cellWidth/2);arcY = 8*cellHeight;


        arcXMax = 1044-72;arcXMin = 72;arcYMax = 960-60;arcYMin = 60;
        arcRadius = 10;
        arcMove = 2;

        arcDirection ='0';
        playerMovementOn = false;


        coins = LegalPoints.returnLegalPoints();
        noCoinLegalPoints = LegalButNoCoinPoints.returnLegalButNoCoinPoints();





        //* ALl monster*//

        //RED GHOST//
        redGhostX= (14*cellWidth)+(cellWidth)/2;redGhostY=(20*cellHeight);


        redGhostScatterX = 29*36;
        redGhostScatterY = 32*30;

        redGhostEatenMode = false;
        redGhostScatterModeOn = true;
        redGhostChaseModeOn = false;

        modeChangeTimeInterval = 25;





        redGhostRadius = 10;
        redGhostMove= 2;
        redGhostMovementOn = false;
        redRight=false;redLeft=false;redUp=false;redDown=false;



        // ajke

        redGhostFrightenedModeOn = false;



        timeDurationOfGhostFrightenedModeRedMonster = 0;
        directionChangedOnFrightenedModeRed = false;
        isDirectionChangedOnEatenModeRed = false;
        redGhostSpeedIncreasedAfterEaten = false;
        increasedRedGhostSpeedAtEatenMode = 6;
        redGhostMoveInitial = redGhostMove;



        //for pink


        pinkGhostX=pinkGhostXInitial;pinkGhostY=pinkGhostYInitial;



        pinkGhostEatenMode = false;
        pinkGhostScatterModeOn = false;
        pinkGhostChaseModeOn = false;
        pinkGhostFrightenedModeOn = false;

        timeElapsedForPauseToMovementPinkMonster = 0;
        timeElapsedForModeChangePinkMonster = 0;




        pinkGhostMove= pinkGhostMoveInitial;
        pinkGhostMovementOn = false;
        pinkRight=false;pinkLeft=false;pinkUp=false;pinkDown=false;



        timeDurationOfGhostFrightenedModePinkMonster = 0;
        directionChangedOnFrightenedModePink = false;
        isDirectionChangedOnEatenModePink = false;
        pinkGhostSpeedIncreasedAfterEaten = false;
        increasedPinkGhostSpeedAtEatenMode = 6;


        pinkGhostOutOfGhostHouse = false;
        pinkGhostReachedOutOfGhostHouseEatenMode = false;





    }
}
