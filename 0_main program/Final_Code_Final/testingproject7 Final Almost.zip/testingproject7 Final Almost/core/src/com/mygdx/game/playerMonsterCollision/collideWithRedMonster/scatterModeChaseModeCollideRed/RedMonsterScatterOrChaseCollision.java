package com.mygdx.game.playerMonsterCollision.collideWithRedMonster.scatterModeChaseModeCollideRed;

import com.mygdx.game.TheLastLife;

public class RedMonsterScatterOrChaseCollision extends TheLastLife {
    public RedMonsterScatterOrChaseCollision()
    {
        boolean collided = false;

        if(Math.abs(redGhostX-arcX)<=2  && redGhostY==arcY) collided = true;
        if(Math.abs(redGhostY-arcY)<=2 && redGhostX==arcX) collided = true;

        if(collided)
        {


        }

    }
}
