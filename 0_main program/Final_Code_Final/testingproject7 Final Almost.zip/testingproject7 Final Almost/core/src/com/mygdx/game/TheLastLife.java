package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.mygdx.game.coins.drawCoins.drawingCoinsOnMaze;
import com.mygdx.game.coins.pointsOnMazeForCoins.FrightenedModeCoinPoints;
import com.mygdx.game.coins.pointsOnMazeForCoins.LegalButNoCoinPoints;
import com.mygdx.game.coins.pointsOnMazeForCoins.LegalPoints;
import com.mygdx.game.extra.playerDirectionCommandStore.PlayerDirectionCommandStore;
import com.mygdx.game.monsterModes.decidingModesForAllMonsters.DecidingModesForAllMonsters;
import com.mygdx.game.movementActivityOfPlayerAndMonsters.MovementActivityOfPlayerAndMonsters;
import com.mygdx.game.playerMonsterCollision.PlayerMonsterCollision;

public class TheLastLife extends ApplicationAdapter implements InputProcessor {


	public static float timeState=0f;



	public static float cellWidth = 36;
	public static float cellHeight = 30;



	//Pacman all variables
	public static boolean arcRight = false,arcLeft=false,arcUp=false,arcDown=false;
	public static boolean arcMovementOn = false;
	public static float arcX = (14*cellWidth)+ (cellWidth/2),arcY = 8*cellHeight;


	public static float arcXMax = 1044-72,arcXMin = 72, arcYMax = 960-60, arcYMin = arcYMin = 60;
	public static float arcRadius = 10;
	public static float arcMove = 2;

	public static char arcDirection ='0';

	public static boolean playerMovementOn = false;


	public static float[][] coins = LegalPoints.returnLegalPoints();
	public static float[][] noCoinLegalPoints = LegalButNoCoinPoints.returnLegalButNoCoinPoints();
	public static float[][] noteEatenCoins = new float[30][32];
	public static ShapeRenderer shapeRenderer;


	public SpriteBatch batch;
	public Texture img;



	//* ALl monster*//
	public static long modeChangeTimeInterval = 25;
	//RED GHOST//
	public static float redGhostXInitial = (14*cellWidth)+(cellWidth)/2,redGhostYInitial=(20*cellHeight);
	public static float redGhostX=redGhostXInitial,redGhostY=redGhostYInitial;

	public static float redGhostScatterX = 29*36;
	public static float redGhostScatterY = 32*30;

	public static boolean redGhostEatenMode = false;
	public static boolean redGhostScatterModeOn = true;
	public static boolean redGhostChaseModeOn = false;

	public static long timeElapsedForPauseToMovementRedMonster = 0;
	public static long timeElapsedForModeChangeRedMonster = 0;



	public static float redGhostRadius = 10;
	public static float redGhostMove= 2;
	public static boolean redGhostMovementOn = false;
	public static boolean redRight=false,redLeft=false,redUp=false,redDown=false;




	// ajke

	public static float[][] coinForFrightenedMode = FrightenedModeCoinPoints.returnFrightenedCoin();
	public static boolean redGhostFrightenedModeOn = false;
	public static long timeDurationOfGhostFrightenedModeRedMonster = 0;
	public static boolean directionChangedOnFrightenedModeRed = false;
	public static boolean isDirectionChangedOnEatenModeRed = false;
	public static boolean redGhostSpeedIncreasedAfterEaten = false;
	public static long increasedRedGhostSpeedAtEatenMode = 6;
	public static float redGhostMoveInitial = redGhostMove;



	//for pinkMonster

	public static float pinkGhostXInitial = (14*cellWidth)+(cellWidth)/2,pinkGhostYInitial=(20*cellHeight)-(3*cellHeight);
	public static float pinkGhostX=pinkGhostXInitial,pinkGhostY=pinkGhostYInitial;

	public static float pinkGhostScatterX = 0;
	public static float pinkGhostScatterY = 32*30;

	public static boolean pinkGhostEatenMode = false;
	public static boolean pinkGhostScatterModeOn = false;
	public static boolean pinkGhostChaseModeOn = false;
	public static boolean pinkGhostFrightenedModeOn = false;

	public static long timeElapsedForPauseToMovementPinkMonster = 0;
	public static long timeElapsedForModeChangePinkMonster = 0;



	public static float pinkGhostRadius = 10;
	public static float pinkGhostMove= 2;
	public static boolean pinkGhostMovementOn = false;
	public static boolean pinkRight=false,pinkLeft=false,pinkUp=false,pinkDown=false;



	public static long timeDurationOfGhostFrightenedModePinkMonster = 0;
	public static boolean directionChangedOnFrightenedModePink = false;
	public static boolean isDirectionChangedOnEatenModePink = false;
	public static boolean pinkGhostSpeedIncreasedAfterEaten = false;
	public static long increasedPinkGhostSpeedAtEatenMode = 6;

	public static float pinkGhostMoveInitial = redGhostMove;


   public static boolean pinkGhostOutOfGhostHouse = false;
   public static boolean pinkGhostReachedOutOfGhostHouseEatenMode = false;



	@Override
	public void create () {

		batch = new SpriteBatch();
		img = new Texture("mugdha2.png");

		shapeRenderer = new ShapeRenderer();
		for(int i=0;i<30;i++)
		{
			for(int j=0;j<32;j++){
				if(coins[i][j]==1) noteEatenCoins[i][j]=1;
			}
		}

	}

	@Override
	public void render () {
		Gdx.input.setInputProcessor((InputProcessor) this);

		timeState += Gdx.graphics.getDeltaTime();
		if(timeState>=1f){
			timeState=0f;

			// forRed
			timeElapsedForPauseToMovementRedMonster++;
			if(playerMovementOn && redGhostFrightenedModeOn==false && redGhostEatenMode ==false)timeElapsedForModeChangeRedMonster++;
			if(redGhostFrightenedModeOn) timeDurationOfGhostFrightenedModeRedMonster++;

			//forPink
			timeElapsedForPauseToMovementPinkMonster++;
			if(playerMovementOn && pinkGhostFrightenedModeOn==false && pinkGhostEatenMode ==false)timeElapsedForModeChangePinkMonster++;
			if(pinkGhostFrightenedModeOn) timeDurationOfGhostFrightenedModePinkMonster++;


		}

		//Background bg = new Background();
		batch.begin();
		batch.draw(img,0,0);
		batch.end();


		drawingCoinsOnMaze drawingCoinsOnMaze = new drawingCoinsOnMaze();
		MovementActivityOfPlayerAndMonsters movementActivityOfPlayerAndMonsters = new MovementActivityOfPlayerAndMonsters();
		DecidingModesForAllMonsters decidingModesForAllMonsters = new DecidingModesForAllMonsters();
		PlayerMonsterCollision playerMonsterCollision = new PlayerMonsterCollision();



	}


	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
		shapeRenderer.dispose();
	}

	@Override
	public boolean keyDown(int keycode) {
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		if(playerMovementOn) {
			PlayerDirectionCommandStore pacdisto = new PlayerDirectionCommandStore(character);}
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}

	@Override
	public boolean scrolled(float amountX, float amountY) {
		return false;
	}
}
