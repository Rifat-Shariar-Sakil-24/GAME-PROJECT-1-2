package com.mygdx.game.movementActivityOfPlayerAndMonsters.monstersMovementActivity.decidingActivityOnOrOffForPinkMonster.pinkMonsterMovementOn.pinkMonsterGoingOut;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.mygdx.game.TheLastLife;

public class PinkMonsterGoingOut extends TheLastLife {
    public PinkMonsterGoingOut()
    {
        pinkGhostY+=pinkGhostMove;
        drawPinkMonster();
        if(pinkGhostY==redGhostYInitial) pinkGhostOutOfGhostHouse = true;
    }

    private void drawPinkMonster() {
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.PINK);
        shapeRenderer.circle(pinkGhostX,pinkGhostY,pinkGhostRadius);
        shapeRenderer.end();
    }
}
