package com.mygdx.game.movementActivityOfPlayerAndMonsters.playerMovementActivity.playerMovementOn.playerMovementOnDirection;

import com.mygdx.game.TheLastLife;

public class PlayerRightMovement extends TheLastLife {
    public PlayerRightMovement()
    {

        boolean On = false;
        if(arcY%cellHeight==0 && arcY/cellHeight==17 && arcX/cellWidth>=27)
        {


            if(arcRight) {
                shapeRenderer.arc(arcX,arcY,arcRadius,45,270);
                if(arcX >= 1044+arcRadius){
                    arcX = -arcRadius;
                }
                arcX += arcMove;
                On = true;
            }
            else if(arcLeft) {

                shapeRenderer.arc(arcX,arcY,arcRadius,-135,270);
                arcX-=arcMove;
                On = true;
            }

        }


        else if(arcY%cellHeight==0 && arcY/cellHeight==17 && arcX/cellWidth<=2)
        {

            if(arcRight) {
                shapeRenderer.arc(arcX,arcY,arcRadius,45,270);
                arcX += arcMove;
                On = true;
            }
            else if(arcLeft) {

                shapeRenderer.arc(arcX,arcY,arcRadius,-135,270);
                if(arcX<=-arcRadius){
                    arcX = 1044+arcRadius;
                }
                arcX-=arcMove;
                On = true;
            }

        }


        if(On == false)
        {

            arcX = Math.min(arcX,arcXMax);

            boolean valid = true;
            if(arcY%cellHeight==0 && arcX%cellWidth==0)
            {
                int x = (int) (arcX/cellWidth);
                int y = (int) (arcY/cellHeight);


                if(noteEatenCoins[x][y]==1 && coinForFrightenedMode[x][y]==1)
                {
                    if(redGhostEatenMode==false)
                    {
                        redGhostFrightenedModeOn = true;
                        redGhostChaseModeOn = false;
                        redGhostScatterModeOn = false;
                    }

                    if(pinkGhostEatenMode==false)
                    {
                        pinkGhostFrightenedModeOn = true;
                        pinkGhostChaseModeOn = false;
                        pinkGhostScatterModeOn = false;
                    }
                    timeDurationOfGhostFrightenedModePinkMonster = 0;
                    timeDurationOfGhostFrightenedModeRedMonster = 0;

                }
                noteEatenCoins[x][y]=0;
                coinForFrightenedMode[x][y]=0;

                if(arcDirection=='w' && (coins[x][y+1]==1 || noCoinLegalPoints[x][y+1]==1))
                {
                    arcRight=arcLeft=arcUp=arcDown=false;
                    arcUp=true;
                }
                else if(arcDirection=='s' && (coins[x][y-1]==1 || noCoinLegalPoints[x][y-1]==1))
                {
                    arcRight=arcLeft=arcUp=arcDown=false;
                    arcDown=true;
                }
                if(coins[x+1][y]==0  && noCoinLegalPoints[x+1][y]==0) valid = false;

            }
            shapeRenderer.arc(arcX,arcY,arcRadius,45,270);
            if(arcX!=arcXMax && arcRight && valid)arcX += arcMove;
        }



    }
}
