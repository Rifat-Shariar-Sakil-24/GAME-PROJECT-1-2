package com.mygdx.game.movementActivityOfPlayerAndMonsters.monstersMovementActivity.decidingActivityOnOrOffForRedMonster.redMonsterMovementOn;

import com.mygdx.game.TheLastLife;
import com.mygdx.game.movementActivityOfPlayerAndMonsters.monstersMovementActivity.decidingActivityOnOrOffForRedMonster.redMonsterMovementOn.redMonsterMovementBasedOnModes.RedMonsterMovementBasedOnModes;

public class RedMonsterMovementOn extends TheLastLife {
    public RedMonsterMovementOn()
    {
        RedMonsterMovementBasedOnModes redMonsterMovementBasedOnModes  = new RedMonsterMovementBasedOnModes();
    }
}
