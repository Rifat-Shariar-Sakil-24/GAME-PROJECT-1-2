package com.mygdx.game.monsterModes.directionChangeForSuddenModeChange.directionChangeOfPinkMonster;

import com.mygdx.game.TheLastLife;

public class DirectionChangeOfPinkMonster extends TheLastLife {
    public DirectionChangeOfPinkMonster()
    {
        if(pinkRight)
        {
            pinkLeft = true;
            pinkRight = false;
            pinkGhostX -= pinkGhostMove;
        }
        else if(pinkLeft)
        {
            pinkLeft = false;
            pinkRight = true;
            pinkGhostX += pinkGhostMove;
        }
        else if(pinkUp)
        {
            pinkUp = false;
            pinkDown = true;
            pinkGhostY -= pinkGhostMove;
        }
        else
        {
            pinkDown = false;
            pinkUp = true;
            pinkGhostY += pinkGhostMove;
        }
    }
}
